import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Box } from '@mui/material';
import Sidebar from './components/Sidebar';
import AuthRoute from './components/AuthRoute';
import DashboardPage from './pages/DashboardPage';
import UploadPage from './pages/UploadPage';
import HistoryPage from './pages/HistoryPage';
import TestUpload from './components/TestUpload';
import ReportsPage from './pages/ReportsPage';
import SettingsPage from './pages/SettingsPage';
import Results from './pages/Results';
import Login from './pages/Login';
import Register from './pages/Register';
import DeveloperPage from './pages/DeveloperPage';

export default function App() {
  return (
    <BrowserRouter>
      <Box sx={{ display: 'flex' }}>
        <Sidebar />
        <Box
          component="main"
          sx={{
            flexGrow: 1,
            pl: { xs: 2, md: 1 }, // Reduced left padding to move content closer to sidebar
            pr: { xs: 2, md: 3 }, // Keep right padding for visual balance
            pt: { xs: '64px', md: 2 },
            pb: 2,
            width: { md: `calc(100% - 240px)` }, // Slightly reduced offset
            ml: { md: '240px' }, // Moved content closer to sidebar
            minHeight: '100vh',
            bgcolor: 'background.default',
            overflow: 'auto',
            '& > *': {
              maxWidth: '1400px', // Increased max width for more content space
              pr: { md: 2 } // Add some padding on the right for larger screens
            }
          }}
        >
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/" element={<AuthRoute><DashboardPage /></AuthRoute>} />
            <Route path="/dashboard" element={<AuthRoute><DashboardPage /></AuthRoute>} />
            <Route path="/upload" element={<AuthRoute><UploadPage /></AuthRoute>} />
            <Route path="/test-upload" element={<AuthRoute><TestUpload /></AuthRoute>} />
            <Route path="/results" element={<AuthRoute><Results /></AuthRoute>} />
            <Route path="/history" element={<AuthRoute><HistoryPage /></AuthRoute>} />
            <Route path="/reports" element={<AuthRoute><ReportsPage /></AuthRoute>} />
            <Route path="/settings" element={<AuthRoute><SettingsPage /></AuthRoute>} />
            <Route path="/developer" element={<AuthRoute><DeveloperPage /></AuthRoute>} />
          </Routes>
        </Box>
      </Box>
    </BrowserRouter>
  );
}
