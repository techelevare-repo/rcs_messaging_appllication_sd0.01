import React, { useState } from 'react';
import axios from 'axios';
import {
  Box,
  Button,
  Typography,
  Card,
  CardContent,
  Alert,
  LinearProgress
} from '@mui/material';

export default function TestUpload() {
  const [file, setFile] = useState(null);
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [prediction, setPrediction] = useState(null);
  const [error, setError] = useState(null);

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      setFile(selectedFile);
      setPrediction(null);
      setError(null);
      setMessage('');
    }
  };

  const handleUpload = async () => {
    try {
      const token = localStorage.getItem('token');
      if (!token) {
        setError('No token found. Please login first.');
        return;
      }

      setLoading(true);
      setError(null);
      setPrediction(null);

      const formData = new FormData();
      formData.append('xray', file);

      console.log('Starting upload...');
      console.log('File:', file.name);
      
      const response = await axios.post('http://localhost:5000/api/predict', formData, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      console.log('Upload response:', response.data);
      
      if (response.data.success) {
        setPrediction({
          prediction: response.data.prediction.result,
          confidence: response.data.prediction.confidence,
          probabilities: response.data.prediction.probabilities
        });
        setMessage('Analysis completed successfully');
      } else {
        setError('Failed to get prediction results');
      }
    } catch (error) {
      console.error('Upload failed:', error);
      setError(error.response?.data?.message || error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box sx={{ maxWidth: 600, mx: 'auto', p: 2 }}>
      <Card>
        <CardContent>
          <Typography variant="h5" gutterBottom>X-Ray Analysis</Typography>

          <Box sx={{ mb: 3 }}>
            <input
              type="file"
              accept="image/*"
              onChange={handleFileChange}
              style={{ display: 'none' }}
              id="x-ray-upload"
            />
            <label htmlFor="x-ray-upload">
              <Button
                variant="contained"
                component="span"
                disabled={loading}
              >
                Choose File
              </Button>
            </label>
            {file && (
              <Typography variant="body2" sx={{ mt: 1 }}>
                Selected: {file.name}
              </Typography>
            )}
          </Box>

          <Button
            variant="contained"
            color="primary"
            onClick={handleUpload}
            disabled={!file || loading}
            fullWidth
            sx={{ mb: 2 }}
          >
            {loading ? 'Analyzing...' : 'Analyze X-Ray'}
          </Button>

          {loading && (
            <Box sx={{ width: '100%', mb: 2 }}>
              <LinearProgress />
            </Box>
          )}

          {error && (
            <Alert severity="error" sx={{ mb: 2 }}>
              {error}
            </Alert>
          )}

          {prediction && (
            <Box sx={{ mt: 2 }}>
              <Alert 
                severity={prediction.prediction === 'non-nodule' ? 'success' : prediction.prediction === 'benign' ? 'info' : 'warning'}
                sx={{ mb: 2 }}
              >
                <Typography variant="h6" component="div" gutterBottom>
                  Classification: {prediction.prediction || 'Unknown'}
                </Typography>
                <Typography>
                  {prediction.prediction === 'non-nodule' && 'No suspicious nodules detected in the image. The X-ray appears normal.'}
                  {prediction.prediction === 'benign' && 'A nodule was detected but appears to have benign characteristics. Regular follow-up may be recommended.'}
                  {prediction.prediction === 'malignant' && 'Suspicious nodule detected with characteristics suggesting potential malignancy. Further investigation is strongly recommended.'}
                </Typography>
              </Alert>
              
              <Card variant="outlined">
                <CardContent>
                  <Typography variant="h6" gutterBottom>Analysis Details</Typography>
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
                    <Typography>
                      <strong>Confidence Score:</strong> {Math.round(prediction.confidence * 100)}%
                    </Typography>
                    {prediction.probabilities && (
                      <>
                        <Typography>
                          <strong>Probability Distribution:</strong>
                        </Typography>
                        <Box sx={{ pl: 2 }}>
                          <Typography>
                            Non-nodule: {(prediction.probabilities[0] * 100).toFixed(1)}%
                          </Typography>
                          <Typography>
                            Malignant: {(prediction.probabilities[1] * 100).toFixed(1)}%
                          </Typography>
                          <Typography>
                            Benign: {(prediction.probabilities[2] * 100).toFixed(1)}%
                          </Typography>
                        </Box>
                      </>
                    )}
                    <Box sx={{ mt: 1 }}>
                      <Typography>
                        <strong>File Details:</strong>
                      </Typography>
                      {file && (
                        <Box sx={{ pl: 2 }}>
                          <Typography>Name: {file.name}</Typography>
                          <Typography>Size: {(file.size / (1024 * 1024)).toFixed(2)} MB</Typography>
                          <Typography>Type: {file.type}</Typography>
                        </Box>
                      )}
                    </Box>
                  </Box>
                </CardContent>
              </Card>
              
              <Typography variant="body2" color="text.secondary" sx={{ mt: 2 }}>
                Note: This is an AI-assisted analysis and should not be used as the sole basis for medical decisions. 
                Please consult with a qualified healthcare professional for proper diagnosis.
              </Typography>
            </Box>
          )}
        </CardContent>
      </Card>
    </Box>
  );
}