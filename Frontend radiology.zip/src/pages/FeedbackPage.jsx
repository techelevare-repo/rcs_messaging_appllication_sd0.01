import FeedbackForm from '../components/FeedbackForm'

export default function FeedbackPage() {
  return (
    <div style={{ maxWidth: 450, margin: 'auto', paddingTop: 36 }}>
      <FeedbackForm />
    </div>
  )
}
