import * as meService from '../services/me.service.js';

// Support tickets
export async function replyToTicket(req, res, next) {
  try {
    const { id } = req.params;
    const userId = req.user.id; // Assuming authentication middleware sets this
    const reply = await meService.addTicketReply(id, userId, req.body);
    res.status(201).json(reply);
  } catch (err) {
    next(err);
  }
}

// Connected accounts
export async function getConnectedAccounts(req, res, next) {
  try {
    const userId = req.user.id;
    const accounts = await meService.getConnectedAccounts(userId);
    res.json(accounts);
  } catch (err) {
    next(err);
  }
}

export async function connectFacebook(req, res, next) {
  try {
    const userId = req.user.id;
    const connection = await meService.connectSocialAccount(userId, 'facebook', req.body);
    res.status(201).json(connection);
  } catch (err) {
    next(err);
  }
}

export async function connectTwitter(req, res, next) {
  try {
    const userId = req.user.id;
    const connection = await meService.connectSocialAccount(userId, 'twitter', req.body);
    res.status(201).json(connection);
  } catch (err) {
    next(err);
  }
}

export async function removeConnection(req, res, next) {
  try {
    const userId = req.user.id;
    const { type } = req.params;
    await meService.removeConnection(userId, type);
    res.status(200).json({ message: `${type} connection removed successfully` });
  } catch (err) {
    next(err);
  }
}

// Audit logs
export async function getAuditLog(req, res, next) {
  try {
    const userId = req.user.id;
    const logs = await meService.getAuditLog(userId);
    res.json(logs);
  } catch (err) {
    next(err);
  }
}

export async function getAuditLogEntry(req, res, next) {
  try {
    const userId = req.user.id;
    const { id } = req.params;
    const log = await meService.getAuditLogEntry(userId, id);
    res.json(log);
  } catch (err) {
    next(err);
  }
}

// Consents
export async function getConsents(req, res, next) {
  try {
    const userId = req.user.id;
    const consents = await meService.getConsents(userId);
    res.json(consents);
  } catch (err) {
    next(err);
  }
}

export async function getConsentByType(req, res, next) {
  try {
    const userId = req.user.id;
    const { type } = req.params;
    const consent = await meService.getConsentByType(userId, type);
    res.json(consent);
  } catch (err) {
    next(err);
  }
}

export async function revokeConsent(req, res, next) {
  try {
    const userId = req.user.id;
    const { type } = req.params;
    await meService.revokeConsent(userId, type);
    res.status(200).json({ message: `${type} consent revoked successfully` });
  } catch (err) {
    next(err);
  }
}

// Add this function to the existing file

// Support tickets
export async function createSupportTicket(req, res, next) {
  try {
    const userId = req.user.id; // Assuming authentication middleware sets this
    const ticket = await meService.createSupportTicket(userId, req.body);
    res.status(201).json(ticket);
  } catch (err) {
    next(err);
  }
}