import { parseExcelBuffer, createPreview, getPreview, commitPreview } from '../services/upload.service.js';

export async function uploadExcel(req, res, next) {
    try {
        if (!req.file) {
            const err = new Error('File is required (field name: file)');
            err.status = 400;
            throw err;
        }
        const rows = parseExcelBuffer(req.file.buffer);
        const sample = rows.slice(0, 10);
        const token = createPreview(rows);
        res.status(200).json({ token, sampleCount: sample.length, sample });
    } catch (err) {
        next(err);
    }
}

export async function getPreviewRows(req, res, next) {
    try {
        const rows = getPreview(req.params.token);
        if (!rows) {
            return res.status(404).json({ error: 'Preview not found or expired' });
        }
        res.json({ count: rows.length, rows: rows.slice(0, 100) });
    } catch (err) {
        next(err);
    }
}

export async function commit(req, res, next) {
    try {
        const result = await commitPreview(req.params.token);
        res.status(201).json(result);
    } catch (err) {
        next(err);
    }
}
