import * as userService from '../services/user.service.js';

export async function listUsers(req, res, next) {
    try {
        const users = await userService.getUsers(req.query);
        res.json(users);
    } catch (err) {
        next(err);
    }
}

export async function createUser(req, res, next) {
  try {
    const user = await userService.createUser(req.body);
    res.status(201).json(user);
  } catch (err) {
    next(err);
  }
}

export async function deleteUser(req, res, next) {
  try {
    const { id } = req.params;
    await userService.deleteUser(id);
    res.status(200).json({ message: 'User deleted successfully' });
  } catch (err) {
    next(err);
  }
}

// Add these functions to the existing file

// Batch operations
export async function batchFetchUsers(req, res, next) {
  try {
    const users = await userService.batchFetchUsers(req.body.ids);
    res.json(users);
  } catch (err) {
    next(err);
  }
}

export async function batchUpdateUsers(req, res, next) {
  try {
    const results = await userService.batchUpdateUsers(req.body.updates);
    res.json(results);
  } catch (err) {
    next(err);
  }
}

export async function batchDeleteUsers(req, res, next) {
  try {
    const results = await userService.batchDeleteUsers(req.body.ids);
    res.json(results);
  } catch (err) {
    next(err);
  }
}

// Geolocation
export async function getNearbyUsers(req, res, next) {
  try {
    const { lat, lng, radius } = req.query;
    const users = await userService.getNearbyUsers(lat, lng, radius);
    res.json(users);
  } catch (err) {
    next(err);
  }
}

export async function getUsersWithinArea(req, res, next) {
  try {
    const { polygon } = req.query;
    const users = await userService.getUsersWithinArea(polygon);
    res.json(users);
  } catch (err) {
    next(err);
  }
}

// Analytics
export async function getRegistrationTrend(req, res, next) {
  try {
    const trend = await userService.getRegistrationTrend();
    res.json(trend);
  } catch (err) {
    next(err);
  }
}

export async function getLocationDistribution(req, res, next) {
  try {
    const distribution = await userService.getLocationDistribution();
    res.json(distribution);
  } catch (err) {
    next(err);
  }
}


