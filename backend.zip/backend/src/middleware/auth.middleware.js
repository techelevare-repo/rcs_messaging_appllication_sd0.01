import db from '../models/index.js';

export async function authMiddleware(req, res, next) {
  try {
    // For testing purposes, we'll use a custom header
    const userId = req.headers['x-user-id'];
    
    if (!userId) {
      return res.status(401).json({ error: 'Authentication required' });
    }
    
    const user = await db.User.findByPk(userId);
    
    if (!user) {
      return res.status(401).json({ error: 'Invalid user' });
    }
    
    // Set the user object on the request
    req.user = user;
    next();
  } catch (err) {
    next(err);
  }
}