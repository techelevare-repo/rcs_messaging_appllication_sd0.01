import multer from 'multer';

const storage = multer.memoryStorage();

export const uploadExcel = multer({
    storage,
    limits: { fileSize: 5 * 1024 * 1024 },
    fileFilter: (_req, file, cb) => {
        const ok = [
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', // .xlsx
            'application/vnd.ms-excel', // .xls
            'text/csv',
        ];
        if (ok.includes(file.mimetype)) return cb(null, true);
        cb(new Error('Only Excel/CSV files are allowed'));
    },
}).single('file');
