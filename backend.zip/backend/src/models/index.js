import { Sequelize, DataTypes } from 'sequelize';
import { sequelize } from '../config/database.js';

import defineUser from './user.model.js';
import defineUserProfile from './userProfile.model.js';
import defineUserLocation from './userLocation.model.js';
import defineUserSettings from './userSettings.model.js';
import defineUserMedia from './userMedia.model.js';
import defineUserActivityLog from './userActivityLog.model.js';
import defineUserAuditLog from './userAuditLog.model.js';
import defineUserConsent from './userConsent.model.js';
import defineUserIntegration from './userIntegration.model.js';
import defineSupportTicket from './supportTicket.model.js';
import defineTicketReply from './ticketReply.model.js';

const db = {};

db.sequelize = sequelize;
db.Sequelize = Sequelize;

db.User = defineUser(sequelize, DataTypes);
db.UserProfile = defineUserProfile(sequelize, DataTypes);
db.UserLocation = defineUserLocation(sequelize, DataTypes);
db.UserSettings = defineUserSettings(sequelize, DataTypes);
db.UserMedia = defineUserMedia(sequelize, DataTypes);
db.UserActivityLog = defineUserActivityLog(sequelize, DataTypes);
db.UserAuditLog = defineUserAuditLog(sequelize, DataTypes);
db.UserConsent = defineUserConsent(sequelize, DataTypes);
db.UserIntegration = defineUserIntegration(sequelize, DataTypes);
db.SupportTicket = defineSupportTicket(sequelize, DataTypes);
db.TicketReply = defineTicketReply(sequelize, DataTypes);

// Associations
db.User.hasOne(db.UserProfile, { foreignKey: 'userId' });
db.User.hasOne(db.UserLocation, { foreignKey: 'userId' });
db.User.hasOne(db.UserSettings, { foreignKey: 'userId' });
db.User.hasMany(db.UserMedia, { foreignKey: 'userId' });
db.User.hasMany(db.UserActivityLog, { foreignKey: 'userId' });
db.User.hasMany(db.UserAuditLog, { foreignKey: 'userId' });
db.User.hasMany(db.UserConsent, { foreignKey: 'userId' });
db.User.hasMany(db.UserIntegration, { foreignKey: 'userId' });
db.User.hasMany(db.SupportTicket, { foreignKey: 'userId' });
db.SupportTicket.hasMany(db.TicketReply, { foreignKey: 'ticketId' });
db.User.hasMany(db.TicketReply, { foreignKey: 'userId' });

export default db;


