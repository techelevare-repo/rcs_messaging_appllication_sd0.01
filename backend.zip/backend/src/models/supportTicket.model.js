export default (sequelize, DataTypes) => {
    const SupportTicket = sequelize.define(
        'SupportTicket',
        {
            id: {
                type: DataTypes.UUID,
                defaultValue: DataTypes.UUIDV4,
                primaryKey: true,
            },
            userId: { type: DataTypes.UUID, allowNull: false },
            subject: DataTypes.STRING,
            status: DataTypes.STRING,
            priority: DataTypes.STRING,
            createdAt: DataTypes.DATE,
            updatedAt: DataTypes.DATE,
        },
        { tableName: 'support_tickets', timestamps: true }
    );
    return SupportTicket;
};