export default (sequelize, DataTypes) => {
    const TicketReply = sequelize.define(
        'TicketReply',
        {
            id: {
                type: DataTypes.UUID,
                defaultValue: DataTypes.UUIDV4,
                primaryKey: true,
            },
            ticketId: { type: DataTypes.UUID, allowNull: false },
            userId: { type: DataTypes.UUID, allowNull: false },
            message: DataTypes.TEXT,
            createdAt: DataTypes.DATE,
        },
        { tableName: 'ticket_replies', timestamps: true }
    );
    return TicketReply;
};