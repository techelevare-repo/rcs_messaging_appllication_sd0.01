export default (sequelize, DataTypes) => {
    const User = sequelize.define(
        'User',
        {
            id: {
                type: DataTypes.UUID,
                defaultValue: DataTypes.UUIDV4,
                primaryKey: true,
            },
            username: { type: DataTypes.STRING, unique: true },
            email: { type: DataTypes.STRING, unique: true },
            phone: DataTypes.STRING,
            passwordHash: { type: DataTypes.STRING },
            role: DataTypes.STRING,
            status: DataTypes.STRING,
            isEmailVerified: DataTypes.BOOLEAN,
            isPhoneVerified: DataTypes.BOOLEAN,
            kycStatus: DataTypes.STRING,
            language: DataTypes.STRING,
            theme: DataTypes.STRING,
            subscriptionPlan: DataTypes.STRING,
            subscriptionStatus: DataTypes.STRING,
            isMockUser: DataTypes.BOOLEAN,
        },
        {
            tableName: 'users',
            timestamps: true,
            underscored: false,
            defaultScope: {
                attributes: { exclude: ['passwordHash'] },
            },
        }
    );

    return User;
};


