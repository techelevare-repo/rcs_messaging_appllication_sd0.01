export default (sequelize, DataTypes) => {
    const UserActivityLog = sequelize.define(
        'UserActivityLog',
        {
            id: {
                type: DataTypes.UUID,
                defaultValue: DataTypes.UUIDV4,
                primaryKey: true,
            },
            userId: { type: DataTypes.UUID, allowNull: false },
            activityType: DataTypes.STRING,
            description: DataTypes.STRING,
            timestamp: DataTypes.DATE,
        },
        { tableName: 'user_activity_logs', timestamps: true }
    );
    return UserActivityLog;
};


