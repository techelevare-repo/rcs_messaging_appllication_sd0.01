export default (sequelize, DataTypes) => {
    const UserAuditLog = sequelize.define(
        'UserAuditLog',
        {
            id: {
                type: DataTypes.UUID,
                defaultValue: DataTypes.UUIDV4,
                primaryKey: true,
            },
            userId: { type: DataTypes.UUID, allowNull: false },
            action: DataTypes.STRING,
            performedBy: DataTypes.STRING,
            timestamp: DataTypes.DATE,
        },
        { tableName: 'user_audit_logs', timestamps: true }
    );
    return UserAuditLog;
};


