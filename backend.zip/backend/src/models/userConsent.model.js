export default (sequelize, DataTypes) => {
    const UserConsent = sequelize.define(
        'UserConsent',
        {
            id: {
                type: DataTypes.UUID,
                defaultValue: DataTypes.UUIDV4,
                primaryKey: true,
            },
            userId: { type: DataTypes.UUID, allowNull: false },
            type: DataTypes.STRING,
            givenAt: DataTypes.DATE,
        },
        { tableName: 'user_consents', timestamps: true }
    );
    return UserConsent;
};


