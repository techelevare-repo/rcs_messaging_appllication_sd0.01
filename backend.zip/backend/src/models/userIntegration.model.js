export default (sequelize, DataTypes) => {
    const UserIntegration = sequelize.define(
        'UserIntegration',
        {
            id: {
                type: DataTypes.UUID,
                defaultValue: DataTypes.UUIDV4,
                primaryKey: true,
            },
            userId: { type: DataTypes.UUID, allowNull: false },
            provider: DataTypes.STRING,
            connected: DataTypes.BOOLEAN,
        },
        { tableName: 'user_integrations', timestamps: true }
    );
    return UserIntegration;
};


