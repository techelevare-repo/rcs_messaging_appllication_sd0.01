export default (sequelize, DataTypes) => {
    const UserLocation = sequelize.define(
        'UserLocation',
        {
            id: {
                type: DataTypes.UUID,
                defaultValue: DataTypes.UUIDV4,
                primaryKey: true,
            },
            userId: { type: DataTypes.UUID, allowNull: false },
            lat: DataTypes.FLOAT,
            lng: DataTypes.FLOAT,
            address: DataTypes.STRING,
            city: DataTypes.STRING,
            state: DataTypes.STRING,
            country: DataTypes.STRING,
            postalCode: DataTypes.STRING,
        },
        { tableName: 'user_locations', timestamps: true }
    );
    return UserLocation;
};


