export default (sequelize, DataTypes) => {
    const UserMedia = sequelize.define(
        'UserMedia',
        {
            id: {
                type: DataTypes.UUID,
                defaultValue: DataTypes.UUIDV4,
                primaryKey: true,
            },
            userId: { type: DataTypes.UUID, allowNull: false },
            mediaType: DataTypes.STRING,
            mediaUrl: DataTypes.STRING,
        },
        { tableName: 'user_media', timestamps: true }
    );
    return UserMedia;
};


