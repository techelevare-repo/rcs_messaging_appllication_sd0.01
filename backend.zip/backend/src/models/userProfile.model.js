export default (sequelize, DataTypes) => {
    const UserProfile = sequelize.define(
        'UserProfile',
        {
            id: {
                type: DataTypes.UUID,
                defaultValue: DataTypes.UUIDV4,
                primaryKey: true,
            },
            userId: {
                type: DataTypes.UUID,
                allowNull: false,
            },
            firstName: DataTypes.STRING,
            lastName: DataTypes.STRING,
            gender: DataTypes.STRING,
            dob: DataTypes.DATE,
            bio: DataTypes.STRING,
            profileImageUrl: DataTypes.STRING,
            coverImageUrl: DataTypes.STRING,
        },
        { tableName: 'user_profiles', timestamps: true }
    );
    return UserProfile;
};


