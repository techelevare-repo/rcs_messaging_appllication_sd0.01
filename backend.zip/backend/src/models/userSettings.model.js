export default (sequelize, DataTypes) => {
    const UserSettings = sequelize.define(
        'UserSettings',
        {
            id: {
                type: DataTypes.UUID,
                defaultValue: DataTypes.UUIDV4,
                primaryKey: true,
            },
            userId: { type: DataTypes.UUID, allowNull: false },
            notificationsEnabled: DataTypes.BOOLEAN,
            showLocation: DataTypes.BOOLEAN,
            showStatus: DataTypes.BOOLEAN,
            allowFollow: DataTypes.BOOLEAN,
        },
        { tableName: 'user_settings', timestamps: true }
    );
    return UserSettings;
};


