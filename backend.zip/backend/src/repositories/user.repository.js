import db from '../models/index.js';

export async function findAll(filter = {}) {
    const where = {};
    if (filter.location) {
        // join via UserLocation
        return db.User.findAll({
            include: [
                db.UserProfile,
                db.UserSettings,
                { model: db.UserLocation, where: { city: filter.location }, required: true },
            ],
        });
    }
    return db.User.findAll({ include: [db.UserProfile, db.UserSettings, db.UserLocation] });
}

export async function create(data) {
  return db.User.create(data);
}

export async function findById(id) {
  return db.User.findByPk(id);
}

export async function findByIds(ids) {
  return db.User.findAll({
    where: {
      id: ids
    },
    include: [db.UserProfile, db.UserSettings, db.UserLocation]
  });
}

export async function deleteById(id) {
  return db.User.destroy({
    where: { id }
  });
}


