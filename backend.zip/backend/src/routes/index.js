import { Router } from 'express';
import userRouter from './user.routes.js';
import uploadRouter from './upload.routes.js';
import meRouter from './me.routes.js';

const router = Router();

router.use('/users', userRouter);
router.use('/users/me', meRouter);
router.use('/', uploadRouter);

export default router;


