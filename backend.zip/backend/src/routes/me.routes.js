import { Router } from 'express';
import * as meController from '../controllers/me.controller.js';
import { authMiddleware } from '../middleware/auth.middleware.js';

const router = Router();

// Apply auth middleware to all routes
router.use(authMiddleware);

// Support tickets
router.post('/support-tickets', meController.createSupportTicket);
router.post('/support-tickets/:id/reply', meController.replyToTicket);

// Connected accounts
router.get('/connected-accounts', meController.getConnectedAccounts);
router.post('/connections/facebook', meController.connectFacebook);
router.post('/connections/twitter', meController.connectTwitter);
router.delete('/connections/:type', meController.removeConnection);

// Audit logs
router.get('/audit-log', meController.getAuditLog);
router.get('/audit-log/:id', meController.getAuditLogEntry);

// Consents
router.get('/consents', meController.getConsents);
router.get('/consents/:type', meController.getConsentByType);
router.delete('/consents/:type', meController.revokeConsent);

export default router;