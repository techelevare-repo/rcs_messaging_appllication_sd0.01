import { Router } from 'express';
import { uploadExcel as uploadMw } from '../middleware/upload.middleware.js';
import * as uploadController from '../controllers/upload.controller.js';

const router = Router();

router.post('/upload', uploadMw, uploadController.uploadExcel);
router.get('/preview/:token', uploadController.getPreviewRows);
router.post('/commit/:token', uploadController.commit);

export default router;


