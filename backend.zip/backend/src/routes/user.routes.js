import { Router } from 'express';
import * as userController from '../controllers/user.controller.js';

const router = Router();

// Existing routes
router.get('/', userController.listUsers);
router.post('/', userController.createUser);
router.delete('/:id', userController.deleteUser);

// Batch operations
router.post('/batch-fetch', userController.batchFetchUsers);
router.post('/batch-update', userController.batchUpdateUsers);
router.post('/batch-delete', userController.batchDeleteUsers);

// Geolocation
router.get('/nearby', userController.getNearbyUsers);
router.get('/within-area', userController.getUsersWithinArea);

// Analytics
router.get('/registration-trend', userController.getRegistrationTrend);
router.get('/location-distribution', userController.getLocationDistribution);

export default router;


