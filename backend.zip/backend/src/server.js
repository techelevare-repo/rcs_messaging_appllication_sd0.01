import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import pino from 'pino';
import pinoHttp from 'pino-http';
import { sequelize } from './config/database.js';
import router from './routes/index.js';
import { errorHandler } from './middleware/error.middleware.js';
import { ensureDatabaseExists } from './config/bootstrap.js';

const app = express();
const logger = pino({ transport: { target: 'pino-pretty' } });

app.use(helmet());
app.use(cors());
app.use(express.json());
app.use(pinoHttp({ logger }));
app.get('/', (_req, res) => {
    res.json({ message: 'Techelevare API. See /health and /api/*' });
});
app.use('/api', router);
app.use(errorHandler);

app.get('/health', (_req, res) => {
    res.json({ status: 'ok' });
});

const port = process.env.PORT || 4000;

async function start() {
    try {
        await ensureDatabaseExists();
        await sequelize.authenticate();
        await sequelize.sync();
        logger.info('Database connection has been established successfully.');
        app.listen(port, () => {
            logger.info(`Server is running on http://localhost:${port}`);
        });
    } catch (error) {
        logger.error(error, 'Unable to connect to the database:');
        process.exit(1);
    }
}

start();


