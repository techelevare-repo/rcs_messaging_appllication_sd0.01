import db from '../models/index.js';

// Support tickets
export async function addTicketReply(ticketId, userId, payload) {
  const ticket = await db.SupportTicket.findByPk(ticketId);
  if (!ticket) {
    const err = new Error('Ticket not found');
    err.status = 404;
    throw err;
  }
  
  if (ticket.userId !== userId) {
    const err = new Error('Unauthorized');
    err.status = 403;
    throw err;
  }
  
  const reply = await db.TicketReply.create({
    ticketId,
    userId,
    message: payload.message,
  });
  
  return reply;
}

// Connected accounts
export async function getConnectedAccounts(userId) {
  return db.UserIntegration.findAll({
    where: { userId, connected: true },
  });
}

export async function connectSocialAccount(userId, provider, payload) {
  // Check if connection already exists
  const existingConnection = await db.UserIntegration.findOne({
    where: { userId, provider },
  });
  
  if (existingConnection) {
    existingConnection.connected = true;
    await existingConnection.save();
    return existingConnection;
  }
  
  // Create new connection
  return db.UserIntegration.create({
    userId,
    provider,
    connected: true,
  });
}

export async function removeConnection(userId, provider) {
  const connection = await db.UserIntegration.findOne({
    where: { userId, provider },
  });
  
  if (!connection) {
    const err = new Error('Connection not found');
    err.status = 404;
    throw err;
  }
  
  connection.connected = false;
  await connection.save();
  return { message: `${provider} connection removed successfully` };
}

// Audit logs
export async function getAuditLog(userId) {
  return db.UserAuditLog.findAll({
    where: { userId },
    order: [['timestamp', 'DESC']],
  });
}

export async function getAuditLogEntry(userId, logId) {
  const log = await db.UserAuditLog.findOne({
    where: { id: logId, userId },
  });
  
  if (!log) {
    const err = new Error('Audit log entry not found');
    err.status = 404;
    throw err;
  }
  
  return log;
}

// Consents
export async function getConsents(userId) {
  return db.UserConsent.findAll({
    where: { userId },
  });
}

export async function getConsentByType(userId, type) {
  const consent = await db.UserConsent.findOne({
    where: { userId, type },
  });
  
  if (!consent) {
    const err = new Error('Consent not found');
    err.status = 404;
    throw err;
  }
  
  return consent;
}

export async function revokeConsent(userId, type) {
  const consent = await db.UserConsent.findOne({
    where: { userId, type },
  });
  
  if (!consent) {
    const err = new Error('Consent not found');
    err.status = 404;
    throw err;
  }
  
  await consent.destroy();
  return { message: `${type} consent revoked successfully` };
}

// Add this function to the existing file

// Support tickets
export async function createSupportTicket(userId, payload) {
  const ticket = await db.SupportTicket.create({
    userId,
    subject: payload.subject,
    status: 'open',
    priority: payload.priority || 'medium',
  });
  
  // If there's an initial message, create a reply
  if (payload.message) {
    await db.TicketReply.create({
      ticketId: ticket.id,
      userId,
      message: payload.message,
    });
  }
  
  return ticket;
}