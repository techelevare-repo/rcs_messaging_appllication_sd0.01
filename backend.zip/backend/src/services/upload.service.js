import * as XLSX from 'xlsx';
import crypto from 'crypto';
import db from '../models/index.js';

const previewCache = new Map(); // token -> { rows, expiresAt }
const PREVIEW_TTL_MS = 10 * 60 * 1000;

function normalizeHeader(h) {
    return String(h || '')
        .trim()
        .toLowerCase()
        .replace(/\s+/g, '_');
}

export function parseExcelBuffer(buffer) {
    const workbook = XLSX.read(buffer, { type: 'buffer' });
    const firstSheet = workbook.SheetNames[0];
    const sheet = workbook.Sheets[firstSheet];
    const json = XLSX.utils.sheet_to_json(sheet, { header: 1 });
    if (!json.length) return [];
    const headers = json[0].map(normalizeHeader);
    const rows = json.slice(1).map((row) => {
        const obj = {};
        headers.forEach((h, i) => {
            obj[h] = row[i];
        });
        return obj;
    });
    return rows;
}

export function createPreview(rows) {
    const token = crypto.randomBytes(16).toString('hex');
    previewCache.set(token, { rows, expiresAt: Date.now() + PREVIEW_TTL_MS });
    return token;
}

export function getPreview(token) {
    const entry = previewCache.get(token);
    if (!entry) return null;
    if (Date.now() > entry.expiresAt) {
        previewCache.delete(token);
        return null;
    }
    return entry.rows;
}

export async function commitPreview(token) {
    const rows = getPreview(token);
    if (!rows) {
        const err = new Error('Preview expired or not found');
        err.status = 400;
        throw err;
    }

    // Map expected columns
    // contact, upi_id, shop_name, location
    const mapped = rows
        .map((r) => ({
            contact: r.contact || r.phone || r.mobile,
            upiId: r.upi_id || r.upi || r.vpa,
            shopName: r.shop_name || r.shop || r.store_name,
            location: r.location || r.city || r.area,
        }))
        .filter((r) => r.contact || r.upiId || r.shopName || r.location);

    // Persist into User + Profile/Location minimal fields if needed
    for (const m of mapped) {
        const user = await db.User.create({
            username: m.shopName || m.contact || crypto.randomBytes(4).toString('hex'),
            email: `${crypto.randomBytes(5).toString('hex')}@example.com`,
            phone: m.contact || null,
            status: 'active',
        });
        await db.UserProfile.create({ userId: user.id, firstName: m.shopName || null });
        await db.UserLocation.create({ userId: user.id, city: m.location || null });
    }

    previewCache.delete(token);
    return { inserted: mapped.length };
}
