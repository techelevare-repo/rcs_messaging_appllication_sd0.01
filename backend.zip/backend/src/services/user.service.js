import Joi from 'joi';
import bcrypt from 'bcrypt';
import * as userRepository from '../repositories/user.repository.js';

const createUserSchema = Joi.object({
    username: Joi.string().min(3).max(50).required(),
    email: Joi.string().email().required(),
    phone: Joi.string().optional(),
    password: Joi.string().min(6).required(),
});

export async function getUsers(query = {}) {
    const location = query.location || undefined;
    return userRepository.findAll({ location });
}

export async function createUser(payload) {
    const { value, error } = createUserSchema.validate(payload);
    if (error) {
        const err = new Error(error.message);
        err.status = 400;
        throw err;
    }

    const passwordHash = await bcrypt.hash(value.password, 10);
    const created = await userRepository.create({
        username: value.username,
        email: value.email,
        phone: value.phone,
        passwordHash,
        status: 'active',
    });

    const plain = created.get({ plain: true });
    delete plain.passwordHash;
    return plain;
}

export async function deleteUser(userId) {
    const user = await userRepository.findById(userId);
    if (!user) {
        const err = new Error('User not found');
        err.status = 404;
        throw err;
    }

    await userRepository.deleteById(userId);
    return { message: 'User deleted successfully' };
}

// Add these functions to the existing file

// Batch operations
export async function batchFetchUsers(ids) {
  return userRepository.findByIds(ids);
}

export async function batchUpdateUsers(updates) {
  const results = [];
  
  for (const update of updates) {
    try {
      const user = await userRepository.findById(update.id);
      if (!user) {
        results.push({ id: update.id, success: false, message: 'User not found' });
        continue;
      }
      
      await user.update(update.data);
      results.push({ id: update.id, success: true });
    } catch (error) {
      results.push({ id: update.id, success: false, message: error.message });
    }
  }
  
  return results;
}

export async function batchDeleteUsers(ids) {
  const results = [];
  
  for (const id of ids) {
    try {
      const user = await userRepository.findById(id);
      if (!user) {
        results.push({ id, success: false, message: 'User not found' });
        continue;
      }
      
      await userRepository.deleteById(id);
      results.push({ id, success: true });
    } catch (error) {
      results.push({ id, success: false, message: error.message });
    }
  }
  
  return results;
}

// Geolocation
export async function getNearbyUsers(lat, lng, radius) {
  // This would require a spatial database or calculation
  // For now, we'll implement a simple version
  const allUsers = await userRepository.findAll();
  
  // Filter users based on distance calculation
  // This is a simplified version - in production you'd use a spatial database
  const nearbyUsers = allUsers.filter(user => {
    if (!user.UserLocation) return false;
    
    // Calculate distance using Haversine formula
    const distance = calculateDistance(
      lat, 
      lng, 
      user.UserLocation.latitude, 
      user.UserLocation.longitude
    );
    
    return distance <= radius;
  });
  
  return nearbyUsers;
}

export async function getUsersWithinArea(polygon) {
  // This would require a spatial database
  // For now, we'll return a placeholder
  return [];
}

// Analytics
export async function getRegistrationTrend() {
  const users = await userRepository.findAll();
  
  // Group users by registration date
  const trend = {};
  users.forEach(user => {
    const date = user.createdAt.toISOString().split('T')[0];
    trend[date] = (trend[date] || 0) + 1;
  });
  
  return Object.entries(trend).map(([date, count]) => ({ date, count }));
}

export async function getLocationDistribution() {
  const users = await userRepository.findAll({
    include: [db.UserLocation],
  });
  
  // Group users by location
  const distribution = {};
  users.forEach(user => {
    if (user.UserLocation && user.UserLocation.city) {
      const city = user.UserLocation.city;
      distribution[city] = (distribution[city] || 0) + 1;
    }
  });
  
  return Object.entries(distribution).map(([location, count]) => ({ location, count }));
}

// Helper function for distance calculation
function calculateDistance(lat1, lon1, lat2, lon2) {
  const R = 6371; // Radius of the earth in km
  const dLat = deg2rad(lat2 - lat1);
  const dLon = deg2rad(lon2 - lon1);
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * 
    Math.sin(dLon/2) * Math.sin(dLon/2); 
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
  const d = R * c; // Distance in km
  return d;
}

function deg2rad(deg) {
  return deg * (Math.PI/180);
}


