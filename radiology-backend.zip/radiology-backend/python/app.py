from flask import Flask, request, jsonify
import numpy as np
import tensorflow as tf
from PIL import Image
import io
import os

app = Flask(__name__)

# Import required TensorFlow modules
from tensorflow.keras.applications import Xception
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D
from tensorflow.keras.models import Model

def create_model():
    # Create a base pre-trained Xception model
    base_model = Xception(
        weights='imagenet',  # Use pre-trained ImageNet weights
        include_top=False,   # Don't include the classification layers
        input_shape=(299, 299, 3)  # Standard input size for Xception
    )
    
    # Add custom classification layers
    x = base_model.output
    x = GlobalAveragePooling2D()(x)
    x = Dense(1024, activation='relu')(x)
    predictions = Dense(2, activation='softmax')(x)  # Binary classification (adjust as needed)
    
    # Create the model
    model = Model(inputs=base_model.input, outputs=predictions)
    
    # Freeze the base model layers
    for layer in base_model.layers:
        layer.trainable = False
        
    return model

# Create the model
model = create_model()

@app.route('/predict', methods=['POST'])
def predict():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400
    
    # Process the image
    img = Image.open(io.BytesIO(file.read()))
    img = img.resize((299, 299))  # Resize to 299x299 for Xception
    img_array = np.array(img)
    img_array = np.expand_dims(img_array, axis=0)
    img_array = img_array / 255.0  # Normalize
    
    # Make prediction
    predictions = model.predict(img_array)
    result = {'prediction': float(predictions[0][1]), 'class': int(np.argmax(predictions[0]))}
    
    return jsonify(result)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)