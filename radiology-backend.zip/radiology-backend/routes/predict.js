const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const upload = require('../middleware/upload');
const axios = require('axios');
const Image = require('../models/Image');
const Prediction = require('../models/Prediction');
const fs = require('fs');
const path = require('path');

// @route   POST api/predict
// @desc    Upload image and get prediction
// @access  Private
router.post('/', auth, upload.single('xray'), async (req, res) => {
  console.log('req.body:', req.body);
  console.log('req.file:', req.file);
  try {
    if (!req.file) {
      console.error('No file received by multer.');
      return res.status(400).json({ msg: 'Please upload an image file' });
    }

    // Save image metadata to database
    const image = new Image({
      userId: req.user.id,
      filename: req.file.filename,
      originalName: req.file.originalname,
      path: req.file.path,
      mimetype: req.file.mimetype,
      size: req.file.size
    });

    await image.save();

    // Create form data for Python API
    const formData = new FormData();
    formData.append('file', fs.createReadStream(req.file.path));

    // Send to Python microservice
    const pythonResponse = await axios.post('http://localhost:5000/predict', formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    });

    const { prediction, category, confidence, gradcam_url } = pythonResponse.data;

    // Save prediction to database
    const predictionRecord = new Prediction({
      imageId: image._id,
      userId: req.user.id,
      result: prediction,
      confidence,
      category,
      gradcamUrl: gradcam_url
    });

    await predictionRecord.save();

    // Return prediction results
    res.json({
      prediction,
      confidence,
      gradcam_url,
      category
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});

// @route   GET api/predictions
// @desc    Get all predictions for the logged-in user
// @access  Private
router.get('/predictions', auth, async (req, res) => {
  try {
    const predictions = await Prediction.find({ userId: req.user.id })
      .populate('imageId')
      .sort({ createdAt: -1 });

    res.json(predictions);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});

// @route   GET api/predictions/:id
// @desc    Get a specific prediction
// @access  Private
router.get('/predictions/:id', auth, async (req, res) => {
  try {
    const prediction = await Prediction.findById(req.params.id).populate('imageId');

    if (!prediction) {
      return res.status(404).json({ msg: 'Prediction not found' });
    }

    // Check if the prediction belongs to the user
    if (prediction.userId.toString() !== req.user.id) {
      return res.status(401).json({ msg: 'Not authorized' });
    }

    res.json(prediction);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});

module.exports = router;