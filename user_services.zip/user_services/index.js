const express = require('express');
const { sequelize } = require('./config/config.js');
require('dotenv').config();

const app = express();
app.use(express.json());


const authRoutes = require('./routes/auth.js');
app.use('/auth', authRoutes);

const userRoutes = require('./routes/users.js');
app.use('./users', userRoutes);



app.get('/', (req, res) => {
  res.send('🚀 User Service API is running...');
});

// Sync database
sequelize.sync({ alter: true }).then(() => {
  console.log('✅ Database synchronized');
}).catch(err => {
  console.error('❌ Database sync failed:', err);
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`✅ Server is running on port ${PORT}`);
});
