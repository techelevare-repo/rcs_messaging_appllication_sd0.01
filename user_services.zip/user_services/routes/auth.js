const express = require('express');
const router = express.Router();
const authControllers = require('../controllers/authControllers.js')
// const { register, login } = require('../controllers/authControllers.js');
// const {authenticate, isAdmin } = require('../middleware/authMiddleware.js');
 
router.post('/register', authControllers.register);
router.post('/login', authControllers.login);
router.post('/logout', authControllers.logout);
router.post('/refresh-token', authControllers.refreshToken);
router.post('/forget-password', authControllers.forgotPassword);
router.post('/reset-password', authControllers.resetPassword);
router.delete('/request-account-deletion', authControllers.requestAccountDeletion);

module.exports = router;

