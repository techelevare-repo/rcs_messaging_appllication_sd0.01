const express = require('express');
const router = express.Router();
const userController = require('../controllers/userControllers');
const { authenticate, isAdmin } = require('../middleware/authMiddleware');

// Current user
router.get('/me', authenticate, userController.getMe);
router.put('/me', authenticate, userController.updateMe);

// Admin-only
router.get('/', authenticate, isAdmin, userController.listUsers);
router.post('/', authenticate, isAdmin, userController.createUser);
router.get('/:id', authenticate, isAdmin, userController.getUserById);
router.put('/:id', authenticate, isAdmin, userController.updateUserById);
router.delete('/:id', authenticate, isAdmin, userController.deleteUserById);
router.post('/:id/deactivate', authenticate, isAdmin, userController.deactivateUser);

module.exports = router;
